<!--De functies hieronder bevatter mouseover en mouseout functies die worden toegepast in de tr waar de data in word weer gegeven. Zorg ervoor dat de tr er zo uitziet:
<tr onmouseover="showImg'.$GATcounter.'()" onmouseout="hideImg'.$GATcounter.'()" > 
-->

<!--Deze script functies laten de prullenbak zien zodra de muis over de tr geplaats word, en highlighten de prullenbak zodra de muis daarover word geplaats.-->
<script language="javascript">
	
	function redImg<?php echo $GATcounter?>() {
		document.getElementById("delbut<?php echo $GATcounter?>").src = "trashred.png";
	}
	
	function normalImg<?php echo $GATcounter?>() {
	   document.getElementById("delbut<?php echo $GATcounter?>").src = "trash.png";
	}
	
	function normaldelImg<?php echo $GATcounter?>() {
	   document.getElementById("delbut<?php echo $GATcounter?>").src = "trashdel.png";
	}
	
	function showImg<?php echo $GATcounter?>() {
	 	document.getElementById("delbut<?php echo $GATcounter?>").style.display = "inline";
	}
	
	function hideImg<?php echo $GATcounter?>() {
	 	document.getElementById("delbut<?php echo $GATcounter?>").style.display = "none";
	}
	
</script>

<style>
	.delbutton{
	display: none;
	}
</style>	
	
<?php	
		//zet een knop neer afhankelijk van de "verwijdwerd" waarde
		if($GATdel[$GATa] == 0){
			echo'<image width="15px" class="delbutton" id="delbut'.$GATcounter.'" src="trash.png" onclick="delyes'.$GATcounter.'()" onmouseover="redImg'.$GATcounter.'()" onmouseout="normalImg'.$GATcounter.'()" />';
		}elseif($GATDel[$GATa] !== 0){
			echo'<image width="15px" class="delbutton" id="delbut'.$GATcounter.'" src="trashdel.png" onclick="backyes'.$GATcounter.'()" onmouseover="redImg'.$GATcounter.'()" onmouseout="normaldelImg'.$GATcounter.'()" />';
		}
$GATa++;
	
	?>	
	

	<!--submit een form zodra er op de verwijder knop en op OK word gedrukt-->
	<script language="javascript">
		function delyes<?php echo $GATcounter?>(){
			var hi= confirm("Wilt u deze rij verwijderen?");
   			if (hi== true){
        		document.getElementById("myForm<?php echo $GATcounter?>").submit();
    		}else{}	
		}
	
		function backyes<?php echo $GATcounter?>(){
			var hi= confirm("Wilt u deze rij terugzetten?");
    		if (hi== true){
        		document.getElementById("myForm<?php echo $GATcounter?>").submit();
   			}else{}	
		}
	</script>
	<?php
		$GATcounter++;
	?>