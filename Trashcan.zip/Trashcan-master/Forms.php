<?php	
	// verander dit variabel naar de database die gebruikt word
	$GATdbname = $database;
	
	// verander dit variabel naar de tabel die gebruikt word
	$GATtbname = $table;

	// verander dit variabel naar de query die de data naar de webpagina zet
	$GATquery1 = $query;
	
	//verander dit variabel naar het variabel waarmee verbonden word met de database
	$GATConnection = $connect;
	
	//kijkt of de tabel 'verwijderd' aanwezig is in de tabel en zet deze zo nodig neer
	$GATcheckdel = "SELECT Verwijderd FROM `".$GATtbname."` WHERE 1";
	$GATcheckit = mysqli_query($GATConnection,$GATcheckdel);
	if($GATcheckit == false){ 
	$GATadddel = "ALTER TABLE ".$GATtbname." ADD Verwijderd INT (1) NOT NULL DEFAULT 0;";
	mysqli_query($GATConnection,$GATadddel);
	};
	
	//Link naar de huidige pagina. werkt als refresh
	$GATactual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

	//Telt het aantal kolommen in een database
	$GATsqlcount ='SELECT count(*) FROM information_schema.`COLUMNS` C WHERE table_name = "'.$GATtbname.'" AND TABLE_SCHEMA = "'.$GATdbname.'"';

	//Pakt het aantal kolommen uit een database en zet deze in een variabel
	$GATDBfetchproductC = mysqli_query($GATConnection,$GATsqlcount);
	while($GATproductC = mysqli_fetch_row($GATDBfetchproductC)){
		$GATDBstop = $GATproductC[0];
		
		//-1 omdat dit getal de positie van kolommen moet bekijken en deze reeks begint bij 0
		$GATDBstop = $GATDBstop - 1;
	};



	//Geeft een uniek id bij iedere loop
	$GATcounting = 0;
	
	//Loop voor het genereren van de hidden forms die de verwijderd waarden doorgeven
	//Query 1 is de query die de data op de pagian laad. aka de data die verwijderd zou kunnen worden
	$GATDBfetchproduct1 = mysqli_query($GATConnection,$GATquery1);
	while($GATproduct1 = mysqli_fetch_row($GATDBfetchproduct1)){
		
		//Start een forn wat de waarden kan submitten voor het doorgeven van de waarden die verwijderd moeten worden
		echo '<form method="post" action="" id="myForm'.$GATcounting.'">';
	
		//Query die de namen van de kolommen pakt
		$GATqueryinfo = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='".$GATdbname."' AND `TABLE_NAME`='".$GATtbname."';";

		
		//Pakt de naam van de kolom id
		$GATDBfetchproduct = mysqli_query($GATConnection,$GATqueryinfo);
		$GATproduct = mysqli_fetch_row($GATDBfetchproduct);
		$GATname = $GATproduct[0];
		echo '<input type="hidden" name="value[0]" value="'.$GATname.'">' ;
		
		//Pakt de inhoud van de gegeven kolom
		$GATvalue = $GATproduct1[0]; 
		echo '<input type="hidden" name="content[0]" value="'.$GATvalue.'">'; 

	
		
		
		//Post waarden voor de verborgen inputvelden
		$GATvalues = $_POST['value'];
		$GATcontent = $_POST['content'];
		
		//Zet de kolom en inhoud achter elkaar
		$GATstatuswhere = $GATvalues[0] . " = '" . $GATcontent[0] . "' ";
								

		//Inhoud van de form afhankelijk van de aanwezige verwijderd waarden				
		if($GATproduct1[$GATDBstop] == 0){
			
			//Input nodig voor het kijken of de verandering word doorgegeven
			echo'<input type="hidden" name="deleted'.$GATcounting.'" value="0">';
			
			//Query die de update doorgeeft
			$GATstatusquery1 = 'UPDATE `'.$GATtbname.'` SET `Verwijderd`= 1 WHERE '. $GATstatuswhere.' AND `Verwijderd`= 0 LIMIT 1';
			
			//Kijkt of er op de delete knop word gedrukt
			if(isset($_POST['deleted'.$GATcounting])){
				
				//Voert de verandering door
				mysqli_query($GATConnection,$GATstatusquery1);
				
				//Herlaad de pagina
				?><script type="text/javascript">window.location.href = <?php echo "'".$GATactual_link."';"; ?></script><?php	
			}
		}

		//Inhoud van de form afhankelijk van de aanwezige verwijderd waarden	
		if($GATproduct1[$GATDBstop] == 1){
			
			//Input nodig voor het kijken of de verandering woord doorgegeven
			echo'<input type="hidden" name="deleted'.$GATcounting.'" value="1">';	
			
			//Query die de update doorgeeft
			$GATstatusquery2 = 'UPDATE `'.$GATtbname.'` SET `Verwijderd`= 0 WHERE '. $GATstatuswhere.' AND `Verwijderd`= 1 LIMIT 1';
		
			//Kijkt of er op de delete knop word gedrukt
			if(isset($_POST['deleted'.$GATcounting])){
				
				//Voert de verandering door
				mysqli_query($GATConnection,$GATstatusquery2);
				
				//Herlaad de pagina
				?><script type="text/javascript">window.location.href = <?php echo "'".$GATactual_link."';"; ?></script><?php	
			}
		}
		
		//sluit het form
		echo '</form>';
		
		//nieuw nummer voor een nieuw form
		$GATcounting++;
	}
//zet variabel voor DelToegang.php wat niet geloopt moet worden.
$GATcounter = 0;

$GATa = 0;
	
	$GATdel = "";
	//haalt de "verwijderd" waarden op voor iedere rij en stopt deze in een variabel
	$GATDBfetchproduct2 = mysqli_query($GATConnection,$GATquery1);
	while($GATrows = mysqli_fetch_assoc($GATDBfetchproduct2)){
		$GATdel = $GATdel . $GATrows["Verwijderd"];
	}
?>

