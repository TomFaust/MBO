# Trashcan
A trash can that sets dtabase data to deleted without throwing it away
